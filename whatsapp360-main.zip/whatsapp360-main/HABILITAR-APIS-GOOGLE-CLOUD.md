# Habilitar APIs de Google Cloud

## Errores Detectados

### 1. Network Management API
```
Network Management API has not been used in project astral-adapter-468219-n9 before or it is disabled.
```

### 2. Cloud Identity-Aware Proxy API
```
Cloud Identity-Aware Proxy API has not been used in project astral-adapter-468219-n9 before or it is disabled.
```

## Solución Rápida

### Método 1: Habilitar desde los enlaces directos

Click en estos enlaces (se abrirán en tu navegador):

1. **Network Management API**:
   https://console.developers.google.com/apis/api/networkmanagement.googleapis.com/overview?project=astral-adapter-468219-n9

2. **Cloud Identity-Aware Proxy API**:
   https://console.developers.google.com/apis/api/iap.googleapis.com/overview?project=astral-adapter-468219-n9

En cada página:
- Click en **"HABILITAR"** o **"ENABLE"**
- Esperar 1-2 minutos para que se propague

### Método 2: Desde Google Cloud Console

1. **Ir a APIs & Services**:
   https://console.cloud.google.com/apis/dashboard?project=astral-adapter-468219-n9

2. **Click en "+ ENABLE APIS AND SERVICES"**

3. **Buscar y habilitar**:
   - `Network Management API`
   - `Cloud Identity-Aware Proxy API`

### Método 3: Usando gcloud CLI

```bash
# Habilitar Network Management API
gcloud services enable networkmanagement.googleapis.com --project=astral-adapter-468219-n9

# Habilitar Cloud Identity-Aware Proxy API
gcloud services enable iap.googleapis.com --project=astral-adapter-468219-n9

# Verificar que se habilitaron
gcloud services list --enabled --project=astral-adapter-468219-n9
```

## Después de Habilitar las APIs

1. **Esperar 2-3 minutos** para que los cambios se propaguen

2. **Reintentar la conexión SSH** desde Google Cloud Console

3. **Si aún no funciona**, usar Cloud Shell:
   ```bash
   gcloud compute ssh instance-20251012-183930 --zone=us-central1-a
   ```

## APIs Comunes que Necesitas para Compute Engine

Para evitar futuros problemas, habilita estas APIs también:

```bash
# Compute Engine API (probablemente ya habilitada)
gcloud services enable compute.googleapis.com

# Cloud Resource Manager API
gcloud services enable cloudresourcemanager.googleapis.com

# Service Networking API
gcloud services enable servicenetworking.googleapis.com

# Cloud Logging API
gcloud services enable logging.googleapis.com

# Cloud Monitoring API
gcloud services enable monitoring.googleapis.com
```

O desde la consola:
https://console.cloud.google.com/apis/library?project=astral-adapter-468219-n9

## Verificar APIs Habilitadas

```bash
# Ver todas las APIs habilitadas
gcloud services list --enabled --project=astral-adapter-468219-n9

# Ver APIs disponibles
gcloud services list --available --project=astral-adapter-468219-n9
```

## Conectarse a la VM Después de Habilitar APIs

### Opción 1: Desde Google Cloud Console
1. Ir a https://console.cloud.google.com/compute/instances
2. Click en **SSH** junto a `instance-20251012-183930`
3. Debería abrir una terminal

### Opción 2: Desde Cloud Shell
```bash
gcloud compute ssh instance-20251012-183930 --zone=us-central1-a
```

### Opción 3: Desde tu máquina local
```powershell
gcloud compute ssh instance-20251012-183930 --zone=us-central1-a
```

## Copiar Caddyfile a la VM

Una vez que puedas conectarte:

### Método 1: SCP
```powershell
gcloud compute scp "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\Caddyfile" instance-20251012-183930:~/whatsapp360/Caddyfile --zone=us-central1-a
```

### Método 2: Desde la VM
```bash
# Conectarse a la VM
gcloud compute ssh instance-20251012-183930 --zone=us-central1-a

# Dentro de la VM
cd ~/whatsapp360

# Opción A: Editar directamente
nano Caddyfile

# Opción B: Descargar desde Git (si está en el repo)
git pull origin main

# Copiar a Caddy
sudo cp Caddyfile /etc/caddy/Caddyfile

# Validar
sudo caddy validate --config /etc/caddy/Caddyfile

# Recargar
sudo systemctl reload caddy

# Verificar estado
sudo systemctl status caddy
```

## Troubleshooting

### Si las APIs no se habilitan:

1. **Verificar permisos**:
   - Necesitas rol de `Editor` o `Owner` en el proyecto
   - O rol específico: `Service Usage Admin`

2. **Verificar facturación**:
   - El proyecto debe tener facturación habilitada
   - https://console.cloud.google.com/billing?project=astral-adapter-468219-n9

3. **Verificar cuotas**:
   - https://console.cloud.google.com/iam-admin/quotas?project=astral-adapter-468219-n9

### Si sigue sin conectarse:

```bash
# Ver logs de la VM
gcloud compute instances get-serial-port-output instance-20251012-183930 --zone=us-central1-a

# Reiniciar la VM
gcloud compute instances reset instance-20251012-183930 --zone=us-central1-a

# Esperar 2 minutos y reintentar
```

## Resumen de Pasos

1. ✅ Habilitar **Network Management API**
2. ✅ Habilitar **Cloud Identity-Aware Proxy API**
3. ⏱️ Esperar 2-3 minutos
4. 🔄 Reintentar conexión SSH
5. 📁 Copiar Caddyfile a la VM
6. 🔧 Configurar Caddy
7. ✅ Verificar que funciona

---

**Proyecto**: `astral-adapter-468219-n9`
**VM**: `instance-20251012-183930`
**Zona**: `us-central1-a` (verificar en la consola)
