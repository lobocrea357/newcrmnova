# Solucionar Error de Conexión a VM en Google Cloud

## Error
```
No puedes conectarte a la instancia de VM debido a un error inesperado.
Espera unos minutos y vuelve a intentarlo.
```

## Soluciones

### Solución 1: Verificar Estado de la VM

1. **Ir a Google Cloud Console**:
   - https://console.cloud.google.com/compute/instances

2. **Verificar el estado de la VM**:
   - ✅ Verde = Corriendo
   - ⭕ Gris = Detenida
   - ⚠️ Amarillo = Iniciando

3. **Si está detenida, iniciarla**:
   - Click en los 3 puntos (⋮)
   - Seleccionar "Iniciar/Reanudar"
   - Esperar 1-2 minutos

### Solución 2: Conectarse por SSH desde la Consola

En lugar de usar el botón SSH de la interfaz:

1. **Abrir Cloud Shell** (icono >_ en la parte superior derecha)

2. **Conectarse manualmente**:
```bash
gcloud compute ssh instance-20251012-183930 --zone=ZONA_DE_TU_VM
```

Reemplaza `ZONA_DE_TU_VM` con tu zona (ej: `us-central1-a`, `us-east1-b`, etc.)

### Solución 3: Usar SSH desde tu máquina local

#### Opción A: Generar clave SSH

```powershell
# En PowerShell
ssh-keygen -t rsa -f $env:USERPROFILE\.ssh\google_compute_engine -C "tu_email@gmail.com"
```

#### Opción B: Agregar tu clave SSH a la VM

1. **Ir a Google Cloud Console** → Compute Engine → Metadata
2. **SSH Keys** → Editar
3. **Agregar tu clave pública** (contenido de `~/.ssh/google_compute_engine.pub`)

#### Opción C: Conectarse directamente

```powershell
# Obtener la IP externa de la VM desde la consola
ssh -i $env:USERPROFILE\.ssh\google_compute_engine usuario@IP_EXTERNA_VM
```

### Solución 4: Verificar Firewall

La VM debe tener el puerto SSH (22) abierto:

1. **Ir a VPC Network** → Firewall
2. **Verificar regla** `default-allow-ssh`
3. **Si no existe, crearla**:
   - Nombre: `allow-ssh`
   - Targets: All instances
   - Source IP ranges: `0.0.0.0/0`
   - Protocols and ports: `tcp:22`

### Solución 5: Reiniciar la VM

Si nada funciona:

1. **En Google Cloud Console**:
   - Click en los 3 puntos (⋮)
   - Seleccionar "Reiniciar"
   - Esperar 2-3 minutos

2. **Intentar conectarse de nuevo**

### Solución 6: Ver Logs de la VM

Para diagnosticar el problema:

1. **Ir a la VM** en Google Cloud Console
2. **Click en "Logs"** (en el menú lateral)
3. **Buscar errores** recientes

### Solución 7: Verificar Cuotas y Facturación

A veces Google Cloud detiene VMs por:
- **Cuota de créditos agotada**
- **Tarjeta de crédito expirada**
- **Límites de recursos excedidos**

Verificar en:
- https://console.cloud.google.com/billing
- https://console.cloud.google.com/iam-admin/quotas

## Conectarse desde PowerShell (Windows)

### Método 1: gcloud CLI

```powershell
# Instalar gcloud CLI si no lo tienes
# https://cloud.google.com/sdk/docs/install

# Autenticarse
gcloud auth login

# Configurar proyecto
gcloud config set project TU_PROJECT_ID

# Conectarse
gcloud compute ssh instance-20251012-183930 --zone=us-central1-a
```

### Método 2: SSH Directo

```powershell
# Obtener IP externa de la VM
$VM_IP = "34.57.119.246"  # Reemplazar con tu IP

# Conectarse
ssh -i $env:USERPROFILE\.ssh\google_compute_engine prjsupa@$VM_IP
```

## Editar Caddyfile sin Conectarse a la VM

Si no puedes conectarte, puedes:

### Opción 1: Usar Cloud Shell Editor

1. **Abrir Cloud Shell** en Google Cloud Console
2. **Montar disco de la VM**:
```bash
gcloud compute ssh instance-20251012-183930 --zone=ZONA --command="cat ~/whatsapp360/Caddyfile"
```

### Opción 2: Copiar Caddyfile desde tu máquina

```powershell
# Desde tu máquina Windows
gcloud compute scp Caddyfile instance-20251012-183930:~/whatsapp360/Caddyfile --zone=ZONA
```

### Opción 3: Usar Serial Console

1. **Habilitar Serial Console** en la VM
2. **Conectarse desde Google Cloud Console**
3. **Editar archivos** con `nano` o `vi`

## Comandos Útiles para Diagnosticar

### Desde Cloud Shell:

```bash
# Ver estado de la VM
gcloud compute instances describe instance-20251012-183930 --zone=ZONA

# Ver IP externa
gcloud compute instances describe instance-20251012-183930 --zone=ZONA --format='get(networkInterfaces[0].accessConfigs[0].natIP)'

# Ver logs
gcloud compute instances get-serial-port-output instance-20251012-183930 --zone=ZONA

# Reiniciar VM
gcloud compute instances reset instance-20251012-183930 --zone=ZONA
```

## Transferir Caddyfile a la VM

Una vez que puedas conectarte:

### Método 1: SCP (Recomendado)

```powershell
# Desde tu máquina Windows
gcloud compute scp "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\Caddyfile" instance-20251012-183930:~/whatsapp360/Caddyfile --zone=ZONA
```

### Método 2: Copiar y Pegar

```bash
# En la VM
nano ~/whatsapp360/Caddyfile
# Pegar el contenido del Caddyfile
# Ctrl+X, Y, Enter para guardar
```

### Método 3: Git

```bash
# En la VM
cd ~/whatsapp360
git pull origin main
```

## Verificar que Caddy use el nuevo Caddyfile

```bash
# En la VM
sudo cp ~/whatsapp360/Caddyfile /etc/caddy/Caddyfile
sudo caddy validate --config /etc/caddy/Caddyfile
sudo systemctl reload caddy
sudo systemctl status caddy
```

## Checklist de Verificación

- [ ] VM está corriendo (verde en la consola)
- [ ] Firewall permite SSH (puerto 22)
- [ ] IP externa está asignada
- [ ] Facturación está activa
- [ ] Cuotas no están excedidas
- [ ] Zona correcta en los comandos
- [ ] Credenciales SSH configuradas

## Contacto con Soporte

Si nada funciona:
1. **Crear un ticket** en Google Cloud Support
2. **Incluir**:
   - Nombre de la VM: `instance-20251012-183930`
   - Zona de la VM
   - Mensaje de error completo
   - Logs de la VM

---

**Nota**: La IP `34.57.119.246` es la IP externa de tu VM. Si la VM se reinicia, esta IP puede cambiar a menos que sea una IP estática reservada.
