# Solución: Error de Red Docker

## Error
```
Error response from daemon: failed to set up container networking: 
failed to add interface veth4d7c428 to sandbox: 
failed to get link by name "veth4d7c428": resource temporarily unavailable
```

## Causa
Este error ocurre cuando:
1. Hay interfaces de red huérfanas de contenedores anteriores
2. Docker tiene problemas con el namespace de red
3. Hay demasiadas interfaces virtuales creadas

## Soluciones (en orden de preferencia)

### Solución 1: Limpiar redes de Docker (Recomendado)

```bash
# Detener todos los contenedores
docker compose down

# Limpiar redes no utilizadas
docker network prune -f

# Reintentar
docker compose up -d --build bot11
```

### Solución 2: Reiniciar el servicio de Docker

```bash
# Detener contenedores
docker compose down

# Reiniciar Docker
sudo systemctl restart docker

# Esperar unos segundos
sleep 5

# Reintentar
docker compose up -d --build bot11
```

### Solución 3: Limpiar interfaces de red huérfanas

```bash
# Ver interfaces de red
ip link show | grep veth

# Eliminar interfaces huérfanas (si existen)
sudo ip link delete veth4d7c428 2>/dev/null || true

# Limpiar todo Docker
docker system prune -af --volumes

# Reiniciar Docker
sudo systemctl restart docker

# Reintentar
docker compose up -d --build bot11
```

### Solución 4: Recrear la red de Docker

```bash
# Detener todos los contenedores
docker compose down

# Eliminar la red específica
docker network rm whatsapp360_whatsapp_network 2>/dev/null || true

# Recrear todo
docker compose up -d --build bot11
```

### Solución 5: Reiniciar el servidor (última opción)

Si nada funciona:
```bash
sudo reboot
```

Después del reinicio:
```bash
cd ~/whatsapp360/bot11
docker compose up -d --build bot11
```

## Prevención

Para evitar este problema en el futuro:

### 1. Limpiar regularmente
```bash
# Agregar a cron para ejecutar semanalmente
docker system prune -f
docker network prune -f
```

### 2. Detener contenedores correctamente
```bash
# Siempre usar
docker compose down

# En lugar de
docker stop
```

### 3. Limitar contenedores simultáneos
Si vas a levantar muchos bots, hazlo en grupos:
```bash
# Grupo 1
docker compose up -d bot11 bot12 bot13 bot14 bot15

# Esperar que estén estables
sleep 30

# Grupo 2
docker compose up -d bot16 bot17 bot18 bot19 bot20
```

## Verificar Estado

```bash
# Ver redes de Docker
docker network ls

# Ver interfaces de red del sistema
ip link show | grep veth | wc -l

# Ver uso de recursos
docker stats --no-stream

# Ver logs del daemon de Docker
sudo journalctl -u docker -n 50
```

## Comando Completo de Limpieza

Script para limpiar completamente:

```bash
#!/bin/bash
echo "Deteniendo contenedores..."
docker compose down

echo "Limpiando redes..."
docker network prune -f

echo "Limpiando contenedores detenidos..."
docker container prune -f

echo "Limpiando imágenes sin usar..."
docker image prune -f

echo "Reiniciando Docker..."
sudo systemctl restart docker

echo "Esperando 10 segundos..."
sleep 10

echo "Listo! Ahora puedes ejecutar: docker compose up -d --build bot11"
```

## Si el Error Persiste

1. Verifica que no haya límites del kernel:
```bash
# Ver límites actuales
sysctl net.ipv4.neigh.default.gc_thresh1
sysctl net.ipv4.neigh.default.gc_thresh2
sysctl net.ipv4.neigh.default.gc_thresh3

# Aumentar límites (si es necesario)
sudo sysctl -w net.ipv4.neigh.default.gc_thresh1=1024
sudo sysctl -w net.ipv4.neigh.default.gc_thresh2=2048
sudo sysctl -w net.ipv4.neigh.default.gc_thresh3=4096
```

2. Verifica espacio en disco:
```bash
df -h
```

3. Verifica memoria disponible:
```bash
free -h
```

## Resumen de Comandos Rápidos

```bash
# Opción más rápida (prueba primero)
docker compose down && docker network prune -f && docker compose up -d --build bot11

# Si no funciona
sudo systemctl restart docker && sleep 5 && docker compose up -d --build bot11

# Limpieza completa
docker compose down && docker system prune -af && sudo systemctl restart docker && sleep 10 && docker compose up -d --build bot11
```
