# Dominios Configurados en Caddyfile

## Resumen
Se han configurado **50 bots** en el Caddyfile con sus respectivos subdominios y puertos.

## Lista Completa de Dominios

### Bots 1-10
| Bot | Dominio | Puerto API |
|-----|---------|------------|
| bot1 | bot-uno.novapolointranet.xyz | 3009 |
| bot2 | bot-dos.novapolointranet.xyz | 3010 |
| bot3 | bot-tres.novapolointranet.xyz | 3011 |
| bot4 | bot-cuatro.novapolointranet.xyz | 3012 |
| bot5 | bot-cinco.novapolointranet.xyz | 3013 |
| bot6 | bot-seis.novapolointranet.xyz | 3114 |
| bot7 | bot-siete.novapolointranet.xyz | 3115 |
| bot8 | bot-ocho.novapolointranet.xyz | 3116 |
| bot9 | bot-nueve.novapolointranet.xyz | 3117 |
| bot10 | bot-diez.novapolointranet.xyz | 3118 |

### Bots 11-20
| Bot | Dominio | Puerto API |
|-----|---------|------------|
| bot11 | bot-once.novapolointranet.xyz | 3119 |
| bot12 | bot-doce.novapolointranet.xyz | 3120 |
| bot13 | bot-trece.novapolointranet.xyz | 3121 |
| bot14 | bot-catorce.novapolointranet.xyz | 3122 |
| bot15 | bot-quince.novapolointranet.xyz | 3123 |
| bot16 | bot-dieciseis.novapolointranet.xyz | 3124 |
| bot17 | bot-diecisiete.novapolointranet.xyz | 3125 |
| bot18 | bot-dieciocho.novapolointranet.xyz | 3126 |
| bot19 | bot-diecinueve.novapolointranet.xyz | 3127 |
| bot20 | bot-veinte.novapolointranet.xyz | 3128 |

### Bots 21-30
| Bot | Dominio | Puerto API |
|-----|---------|------------|
| bot21 | bot-veintiuno.novapolointranet.xyz | 3129 |
| bot22 | bot-veintidos.novapolointranet.xyz | 3130 |
| bot23 | bot-veintitres.novapolointranet.xyz | 3131 |
| bot24 | bot-veinticuatro.novapolointranet.xyz | 3132 |
| bot25 | bot-veinticinco.novapolointranet.xyz | 3133 |
| bot26 | bot-veintiseis.novapolointranet.xyz | 3134 |
| bot27 | bot-veintisiete.novapolointranet.xyz | 3135 |
| bot28 | bot-veintiocho.novapolointranet.xyz | 3136 |
| bot29 | bot-veintinueve.novapolointranet.xyz | 3137 |
| bot30 | bot-treinta.novapolointranet.xyz | 3138 |

### Bots 31-40
| Bot | Dominio | Puerto API |
|-----|---------|------------|
| bot31 | bot-treintayuno.novapolointranet.xyz | 3139 |
| bot32 | bot-treintaydos.novapolointranet.xyz | 3140 |
| bot33 | bot-treintaytres.novapolointranet.xyz | 3141 |
| bot34 | bot-treintaycuatro.novapolointranet.xyz | 3142 |
| bot35 | bot-treintaycinco.novapolointranet.xyz | 3143 |
| bot36 | bot-treintayseis.novapolointranet.xyz | 3144 |
| bot37 | bot-treintaysiete.novapolointranet.xyz | 3145 |
| bot38 | bot-treintayocho.novapolointranet.xyz | 3146 |
| bot39 | bot-treintaynueve.novapolointranet.xyz | 3147 |
| bot40 | bot-cuarenta.novapolointranet.xyz | 3148 |

### Bots 41-50
| Bot | Dominio | Puerto API |
|-----|---------|------------|
| bot41 | bot-cuarentayuno.novapolointranet.xyz | 3149 |
| bot42 | bot-cuarentaydos.novapolointranet.xyz | 3150 |
| bot43 | bot-cuarentaytres.novapolointranet.xyz | 3151 |
| bot44 | bot-cuarentaycuatro.novapolointranet.xyz | 3152 |
| bot45 | bot-cuarentaycinco.novapolointranet.xyz | 3153 |
| bot46 | bot-cuarentayseis.novapolointranet.xyz | 3154 |
| bot47 | bot-cuarentaysiete.novapolointranet.xyz | 3155 |
| bot48 | bot-cuarentayocho.novapolointranet.xyz | 3156 |
| bot49 | bot-cuarentaynueve.novapolointranet.xyz | 3157 |
| bot50 | bot-cincuenta.novapolointranet.xyz | 3158 |

### Dashboard
| Servicio | Dominio | Puerto |
|----------|---------|--------|
| Dashboard | dashboard.novapolointranet.xyz | 3100 |

## Configuración DNS Necesaria

Para que estos dominios funcionen, necesitas crear registros DNS tipo **A** o **CNAME** apuntando a tu servidor:

```
bot-uno.novapolointranet.xyz          → IP_DEL_SERVIDOR
bot-dos.novapolointranet.xyz          → IP_DEL_SERVIDOR
bot-tres.novapolointranet.xyz         → IP_DEL_SERVIDOR
...
bot-cincuenta.novapolointranet.xyz    → IP_DEL_SERVIDOR
dashboard.novapolointranet.xyz        → IP_DEL_SERVIDOR
```

O usar un wildcard:
```
*.novapolointranet.xyz → IP_DEL_SERVIDOR
```

## Características de Cada Configuración

Cada bot tiene:
- **Logs individuales**: `/var/log/caddy/bot-[nombre].log`
- **Reverse proxy** al puerto API correspondiente
- **Headers de seguridad** configurados
- **CORS habilitado** para todas las origins
- **Manejo de preflight requests** (OPTIONS)

## Verificar Configuración de Caddy

```bash
# Validar sintaxis del Caddyfile
caddy validate --config /path/to/Caddyfile

# Recargar configuración sin downtime
caddy reload --config /path/to/Caddyfile

# Ver logs de Caddy
journalctl -u caddy -f
```

## Probar Dominios

Una vez configurado el DNS y Caddy:

```bash
# Probar bot11
curl https://bot-once.novapolointranet.xyz/status

# Probar bot50
curl https://bot-cincuenta.novapolointranet.xyz/status

# Probar dashboard
curl https://dashboard.novapolointranet.xyz
```

## Certificados SSL

Caddy generará automáticamente certificados SSL de Let's Encrypt para todos los dominios configurados. Asegúrate de que:

1. Los dominios apunten correctamente al servidor
2. Los puertos 80 y 443 estén abiertos
3. Caddy tenga permisos para escribir en `/var/lib/caddy`

## Estructura del Caddyfile

```
Total de configuraciones: 51 (50 bots + 1 dashboard)
Tamaño aproximado: ~1700 líneas
Puertos utilizados: 3009-3013, 3100, 3114-3158
```

## Comandos Útiles

### Reiniciar Caddy
```bash
sudo systemctl restart caddy
```

### Ver estado de Caddy
```bash
sudo systemctl status caddy
```

### Ver logs de un bot específico
```bash
tail -f /var/log/caddy/bot-once.log
```

### Ver todos los logs
```bash
tail -f /var/log/caddy/*.log
```

## Notas Importantes

1. **Wildcard DNS**: Considera usar un registro wildcard `*.novapolointranet.xyz` para simplificar la configuración DNS
2. **Rate Limiting**: Let's Encrypt tiene límites de certificados por dominio (50 por semana)
3. **Renovación automática**: Caddy renueva automáticamente los certificados SSL
4. **Logs**: Los logs de cada bot se guardan por separado para facilitar el debugging

---

**Fecha de configuración**: 7 de noviembre de 2025
**Total de dominios**: 51 (50 bots + dashboard)
**Estado**: ✅ Configuración completa
