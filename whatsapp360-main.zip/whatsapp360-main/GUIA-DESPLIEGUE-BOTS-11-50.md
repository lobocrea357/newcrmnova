# Guía de Despliegue - Bots 11-50

## ✅ Verificación Completada

```
✓ Dockerfiles configurados: 40/40
✓ Archivos .env configurados: 40/40
✓ Servicios en docker-compose.yml: 50
✓ Volúmenes en docker-compose.yml: 100
```

## 🚀 Pasos para Despliegue

### 1. Verificar Configuración Local

```powershell
# Ejecutar script de verificación
powershell -ExecutionPolicy Bypass -File verificar-configuracion.ps1
```

### 2. Validar docker-compose.yml

```bash
# Validar sintaxis del docker-compose
docker-compose config

# Si hay errores, revisar el archivo
```

### 3. Construir Imágenes (Opcional - Solo para Pruebas Locales)

```bash
# Construir imágenes de bots específicos
docker-compose build bot11 bot12 bot13

# O construir todos los bots nuevos (toma tiempo)
docker-compose build bot11 bot12 bot13 bot14 bot15 bot16 bot17 bot18 bot19 bot20 \
                     bot21 bot22 bot23 bot24 bot25 bot26 bot27 bot28 bot29 bot30 \
                     bot31 bot32 bot33 bot34 bot35 bot36 bot37 bot38 bot39 bot40 \
                     bot41 bot42 bot43 bot44 bot45 bot46 bot47 bot48 bot49 bot50
```

## 📦 Transferir al Servidor

### Opción 1: Git (Recomendado)

```bash
# Agregar cambios al repositorio
git add .
git commit -m "Configuración de bots 11-50 completada"
git push origin main

# En el servidor
git pull origin main
```

### Opción 2: SCP/SFTP

```bash
# Comprimir archivos
tar -czf bots-11-50.tar.gz bot11/ bot12/ ... bot50/ docker-compose.yml

# Transferir al servidor
scp bots-11-50.tar.gz usuario@servidor:/ruta/destino/

# En el servidor, descomprimir
tar -xzf bots-11-50.tar.gz
```

## 🖥️ Despliegue en Servidor

### 1. Preparar el Servidor

```bash
# Conectar al servidor
ssh usuario@servidor

# Navegar al directorio del proyecto
cd /ruta/proyecto/bot

# Verificar que Docker está corriendo
docker --version
docker-compose --version
```

### 2. Verificar Puertos Disponibles

```bash
# Verificar que los puertos 3111-3158 están libres
for port in {3111..3158}; do
    if netstat -tuln | grep -q ":$port "; then
        echo "Puerto $port está en uso"
    fi
done
```

### 3. Iniciar Bots Gradualmente

#### Grupo 1: Bots 11-20 (Prueba inicial)

```bash
docker-compose up -d bot11 bot12 bot13 bot14 bot15 bot16 bot17 bot18 bot19 bot20

# Esperar 2-3 minutos y verificar
docker-compose ps | grep bot1

# Ver logs
docker-compose logs -f bot11
```

#### Grupo 2: Bots 21-30

```bash
docker-compose up -d bot21 bot22 bot23 bot24 bot25 bot26 bot27 bot28 bot29 bot30

# Verificar
docker-compose ps | grep bot2
```

#### Grupo 3: Bots 31-40

```bash
docker-compose up -d bot31 bot32 bot33 bot34 bot35 bot36 bot37 bot38 bot39 bot40

# Verificar
docker-compose ps | grep bot3
```

#### Grupo 4: Bots 41-50

```bash
docker-compose up -d bot41 bot42 bot43 bot44 bot45 bot46 bot47 bot48 bot49 bot50

# Verificar
docker-compose ps | grep bot4
```

### 4. Verificar Estado de Todos los Bots

```bash
# Ver todos los contenedores
docker-compose ps

# Ver solo los nuevos bots
docker-compose ps | grep -E "bot(1[1-9]|[2-4][0-9]|50)"

# Verificar healthchecks
docker ps --format "table {{.Names}}\t{{.Status}}" | grep bot
```

## 🔍 Monitoreo y Verificación

### Verificar Logs de un Bot

```bash
# Ver logs en tiempo real
docker-compose logs -f bot25

# Ver últimas 100 líneas
docker-compose logs --tail=100 bot25

# Ver logs de múltiples bots
docker-compose logs -f bot25 bot26 bot27
```

### Verificar Endpoints de API

```bash
# Verificar status de un bot
curl http://localhost:3133/status

# Verificar múltiples bots
for port in {3119..3158}; do
    echo "Verificando puerto $port..."
    curl -s http://localhost:$port/status | head -1
done
```

### Monitorear Recursos

```bash
# Ver uso de recursos en tiempo real
docker stats

# Ver uso de recursos de bots específicos
docker stats bot11_asesor11 bot12_asesor12 bot13_asesor13
```

## 🔧 Solución de Problemas

### Bot no inicia

```bash
# Ver logs detallados
docker-compose logs bot25

# Reiniciar bot específico
docker-compose restart bot25

# Reconstruir y reiniciar
docker-compose build bot25
docker-compose up -d bot25
```

### Puerto en uso

```bash
# Identificar proceso usando el puerto
netstat -tuln | grep 3125
lsof -i :3125

# Cambiar puerto en .env y Dockerfile si es necesario
```

### Problemas de memoria

```bash
# Ver uso de memoria
free -h

# Detener bots no esenciales
docker-compose stop bot45 bot46 bot47 bot48 bot49 bot50

# Limpiar recursos no usados
docker system prune -a
```

### Volúmenes corruptos

```bash
# Detener bot
docker-compose stop bot25

# Eliminar volumen
docker volume rm bot_bot25_data

# Reiniciar bot (se creará nuevo volumen)
docker-compose up -d bot25
```

## 📊 Comandos Útiles

### Gestión de Bots

```bash
# Detener todos los bots nuevos
docker-compose stop bot11 bot12 bot13 ... bot50

# Reiniciar todos los bots nuevos
docker-compose restart bot11 bot12 bot13 ... bot50

# Eliminar y recrear un bot
docker-compose rm -sf bot25
docker-compose up -d bot25
```

### Limpieza

```bash
# Limpiar imágenes no usadas
docker image prune -a

# Limpiar volúmenes no usados
docker volume prune

# Limpiar todo (cuidado!)
docker system prune -a --volumes
```

### Backup de Sesiones

```bash
# Crear backup de sesiones de un bot
docker run --rm -v bot_bot25_data:/data -v $(pwd):/backup \
    alpine tar czf /backup/bot25_sessions_backup.tar.gz -C /data .

# Restaurar backup
docker run --rm -v bot_bot25_data:/data -v $(pwd):/backup \
    alpine tar xzf /backup/bot25_sessions_backup.tar.gz -C /data
```

## 📈 Escalado y Optimización

### Iniciar Solo Bots Necesarios

```bash
# Ejemplo: Solo bots 11-25 para empezar
docker-compose up -d bot11 bot12 bot13 bot14 bot15 bot16 bot17 bot18 bot19 bot20 \
                     bot21 bot22 bot23 bot24 bot25
```

### Limitar Recursos por Bot

Editar `docker-compose.yml` para agregar límites:

```yaml
bot25:
  # ... configuración existente ...
  deploy:
    resources:
      limits:
        cpus: '0.5'
        memory: 512M
      reservations:
        memory: 256M
```

## ✅ Checklist de Despliegue

- [ ] Verificar configuración local con `verificar-configuracion.ps1`
- [ ] Validar `docker-compose.yml` con `docker-compose config`
- [ ] Transferir archivos al servidor (git/scp)
- [ ] Verificar puertos disponibles en servidor
- [ ] Iniciar bots en grupos de 10
- [ ] Verificar logs de cada grupo
- [ ] Verificar endpoints de API
- [ ] Monitorear uso de recursos
- [ ] Configurar números de WhatsApp (escanear QR)
- [ ] Realizar pruebas de envío/recepción
- [ ] Documentar cualquier problema encontrado
- [ ] Configurar monitoreo continuo

## 🎯 Resultado Esperado

Al finalizar el despliegue deberías tener:

- ✅ 50 bots corriendo (bot1-bot50)
- ✅ Todos los healthchecks en estado "healthy"
- ✅ Todos los endpoints API respondiendo
- ✅ Sesiones de WhatsApp persistentes en volúmenes
- ✅ Logs sin errores críticos
- ✅ Uso de recursos dentro de límites aceptables

## 📞 Soporte

Si encuentras problemas:

1. Revisar logs: `docker-compose logs bot[número]`
2. Verificar configuración: `cat bot[número]/.env`
3. Verificar healthcheck: `docker inspect bot[número]_asesor[número]`
4. Consultar documentación en `CONFIGURACION-BOTS-11-50.md`

---

**Nota**: Recuerda que NO vamos a montar los bots aquí, solo preparar la configuración. El despliegue real se hará en el servidor de producción.
