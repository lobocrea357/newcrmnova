# Copiar Caddyfile Manualmente a la VM

## Problema
El usuario en Cloud Shell no tiene permisos suficientes para usar `gcloud compute scp`.

## Solución 1: Conectarse por SSH Directo

### Paso 1: Conectarse a la VM
```bash
# Desde Cloud Shell
ssh prjsupa@34.57.119.246
```

Si pide contraseña y no la tienes, usa la clave SSH que se generó:
```bash
ssh -i ~/.ssh/google_compute_engine prjsupa@34.57.119.246
```

### Paso 2: Editar el Caddyfile
```bash
cd ~/whatsapp360
nano Caddyfile
```

### Paso 3: Copiar el contenido
Copia TODO el contenido del Caddyfile desde tu archivo local y pégalo en nano.

Presiona:
- `Ctrl+X` para salir
- `Y` para confirmar
- `Enter` para guardar

### Paso 4: Configurar Caddy
```bash
# Copiar a la ubicación de Caddy
sudo cp ~/whatsapp360/Caddyfile /etc/caddy/Caddyfile

# Validar configuración
sudo caddy validate --config /etc/caddy/Caddyfile

# Recargar Caddy
sudo systemctl reload caddy

# Verificar estado
sudo systemctl status caddy
```

## Solución 2: Usar Git

Si tu Caddyfile está en el repositorio Git:

```bash
# Conectarse a la VM
ssh prjsupa@34.57.119.246

# Actualizar desde Git
cd ~/whatsapp360
git pull origin main

# Configurar Caddy
sudo cp Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

## Solución 3: Agregar Permisos IAM

### Desde Google Cloud Console:

1. **Ir a IAM**:
   https://console.cloud.google.com/iam-admin/iam?project=astral-adapter-468219-n9

2. **Buscar** el usuario `lobocreaweb@`

3. **Editar permisos** (icono de lápiz)

4. **Agregar rol**: `Compute Instance Admin (v1)`

5. **Guardar**

6. **Esperar 1-2 minutos** y reintentar

### Roles necesarios:

- `Compute Instance Admin (v1)` - Para gestionar instancias
- O `Editor` - Permisos completos de edición
- O `Owner` - Permisos completos

## Solución 4: Usar Otro Usuario

Si tienes acceso con otro usuario de Google:

```bash
# En Cloud Shell, cambiar de cuenta
gcloud auth login

# Seleccionar la cuenta con permisos

# Reintentar el comando
gcloud compute scp Caddyfile instance-20251012-183930:~/whatsapp360/Caddyfile --zone=us-central1-a
```

## Verificar Permisos Actuales

```bash
# Ver qué permisos tienes
gcloud projects get-iam-policy astral-adapter-468219-n9 \
  --flatten="bindings[].members" \
  --filter="bindings.members:lobocreaweb@*"
```

## Contenido del Caddyfile

El Caddyfile completo está en:
```
c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\Caddyfile
```

Tiene aproximadamente 1730 líneas con configuraciones para:
- 50 bots (bot-uno.novapolointranet.xyz hasta bot-cincuenta.novapolointranet.xyz)
- 1 dashboard (dashboard.novapolointranet.xyz)

## Comandos Rápidos

### Conectarse a la VM:
```bash
ssh prjsupa@34.57.119.246
```

### Editar Caddyfile:
```bash
cd ~/whatsapp360
nano Caddyfile
```

### Aplicar cambios:
```bash
sudo cp ~/whatsapp360/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

### Ver logs:
```bash
sudo journalctl -u caddy -f
```

### Verificar que funciona:
```bash
curl -I http://localhost:3100  # Dashboard
curl -I http://localhost:3009  # Bot 1
curl -I http://localhost:3119  # Bot 11
```

## Notas Importantes

1. **IP de la VM**: `34.57.119.246`
2. **Usuario SSH**: `prjsupa`
3. **Proyecto**: `astral-adapter-468219-n9`
4. **Zona**: `us-central1-a`

---

**Recomendación**: Usa SSH directo (`ssh prjsupa@34.57.119.246`) para evitar problemas de permisos de gcloud.
