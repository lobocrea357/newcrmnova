# Script para actualizar Caddyfile con bots 6-50

$caddyfilePath = "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\Caddyfile"
$botsConfigPath = "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\caddyfile-bots-6-50.txt"

Write-Host "Actualizando Caddyfile con bots 6-50..." -ForegroundColor Cyan

# Leer el contenido actual del Caddyfile
$caddyContent = Get-Content $caddyfilePath -Raw

# Leer la configuración de los bots 6-50
$botsConfig = Get-Content $botsConfigPath -Raw

# Encontrar la posición del DASHBOARD
$dashboardIndex = $caddyContent.IndexOf("# ============================================`n# DASHBOARD")

if ($dashboardIndex -eq -1) {
    Write-Host "ERROR: No se encontro la seccion DASHBOARD" -ForegroundColor Red
    exit 1
}

# Dividir el contenido
$beforeDashboard = $caddyContent.Substring(0, $dashboardIndex)
$fromDashboard = $caddyContent.Substring($dashboardIndex)

# Construir el nuevo contenido
$newContent = $beforeDashboard + $botsConfig + "`n" + $fromDashboard

# Guardar el nuevo Caddyfile
Set-Content -Path $caddyfilePath -Value $newContent -Encoding UTF8

Write-Host "[COMPLETADO] Caddyfile actualizado con bots 6-50" -ForegroundColor Green
Write-Host "Total de bots en Caddyfile: 50" -ForegroundColor Cyan
