# Levantar Bots 11-50 Sin Afectar los Bots 1-10

## Situación Actual
- ✅ Bots 1-10 están corriendo
- 🎯 Objetivo: Levantar bots 11-50 sin detener los existentes

## Solución: Limpiar Solo las Redes Sin Detener Contenedores

### Paso 1: Limpiar redes sin afectar contenedores corriendo

```bash
# Esto NO detiene los contenedores, solo limpia redes no usadas
docker network prune -f
```

### Paso 2: Levantar el bot11 específicamente

```bash
cd ~/whatsapp360/bot11
docker compose up -d --build bot11
```

### Paso 3: Si el error persiste, reiniciar Docker (los contenedores se reinician automáticamente)

```bash
# Los contenedores con restart: unless-stopped se reinician automáticamente
sudo systemctl restart docker

# Esperar a que Docker se estabilice
sleep 10

# Verificar que los bots 1-10 siguen corriendo
docker ps | grep bot

# Levantar bot11
docker compose up -d --build bot11
```

## Método Recomendado: Levantar Bots en Grupos

Para evitar problemas de red, levanta los bots nuevos en grupos pequeños:

### Grupo 1: Bots 11-15
```bash
cd ~/whatsapp360
docker compose up -d --build bot11 bot12 bot13 bot14 bot15

# Verificar que están corriendo
docker ps | grep "bot1[1-5]"

# Ver logs si hay problemas
docker compose logs -f bot11 bot12 bot13 bot14 bot15
```

### Grupo 2: Bots 16-20
```bash
# Esperar 30 segundos antes del siguiente grupo
sleep 30

docker compose up -d --build bot16 bot17 bot18 bot19 bot20
docker ps | grep "bot[12][0-9]"
```

### Grupo 3: Bots 21-25
```bash
sleep 30
docker compose up -d --build bot21 bot22 bot23 bot24 bot25
```

### Grupo 4: Bots 26-30
```bash
sleep 30
docker compose up -d --build bot26 bot27 bot28 bot29 bot30
```

### Grupo 5: Bots 31-35
```bash
sleep 30
docker compose up -d --build bot31 bot32 bot33 bot34 bot35
```

### Grupo 6: Bots 36-40
```bash
sleep 30
docker compose up -d --build bot36 bot37 bot38 bot39 bot40
```

### Grupo 7: Bots 41-45
```bash
sleep 30
docker compose up -d --build bot41 bot42 bot43 bot44 bot45
```

### Grupo 8: Bots 46-50
```bash
sleep 30
docker compose up -d --build bot46 bot47 bot48 bot49 bot50
```

## Script Automatizado

Crea un script para levantar todos los bots nuevos automáticamente:

```bash
#!/bin/bash
# levantar-bots-11-50.sh

cd ~/whatsapp360

echo "=== Limpiando redes no utilizadas ==="
docker network prune -f

echo ""
echo "=== Levantando bots 11-50 en grupos de 5 ==="
echo ""

for start in {11..50..5}; do
    end=$((start + 4))
    if [ $end -gt 50 ]; then
        end=50
    fi
    
    echo ">>> Levantando bots $start-$end..."
    
    bots=""
    for i in $(seq $start $end); do
        bots="$bots bot$i"
    done
    
    docker compose up -d --build $bots
    
    echo "    Esperando 30 segundos antes del siguiente grupo..."
    sleep 30
    echo ""
done

echo ""
echo "=== Verificando todos los bots ==="
docker ps | grep bot | wc -l
echo "bots corriendo"

echo ""
echo "=== Estado de los bots ==="
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep bot
```

### Ejecutar el script:

```bash
# Crear el script
nano ~/whatsapp360/levantar-bots-11-50.sh

# Copiar el contenido del script de arriba

# Dar permisos de ejecución
chmod +x ~/whatsapp360/levantar-bots-11-50.sh

# Ejecutar
./levantar-bots-11-50.sh
```

## Verificar que los Bots 1-10 NO se Afectan

```bash
# Ver todos los bots corriendo
docker ps --format "table {{.Names}}\t{{.Status}}" | grep bot

# Ver específicamente bots 1-10
docker ps | grep -E "bot[1-9]_|bot10_"

# Ver logs de un bot específico para confirmar que sigue funcionando
docker compose logs --tail=20 bot1
```

## Si Necesitas Reiniciar Docker

Los contenedores con `restart: unless-stopped` se reinician automáticamente:

```bash
# Reiniciar Docker
sudo systemctl restart docker

# Esperar a que se estabilice
sleep 15

# Verificar que los bots 1-10 se reiniciaron automáticamente
docker ps | grep -E "bot[1-9]_|bot10_"

# Si alguno no se reinició, levantarlo manualmente
docker compose up -d bot1 bot2 bot3 bot4 bot5 bot6 bot7 bot8 bot9 bot10
```

## Monitoreo Durante el Proceso

### Terminal 1: Ver logs en tiempo real
```bash
# Ver logs de todos los bots
docker compose logs -f --tail=50
```

### Terminal 2: Monitorear recursos
```bash
# Ver uso de recursos
watch -n 5 'docker stats --no-stream'
```

### Terminal 3: Ejecutar comandos
```bash
# Levantar los bots en grupos
```

## Comandos Útiles Durante el Proceso

```bash
# Ver cuántos bots están corriendo
docker ps | grep bot | wc -l

# Ver solo los nombres de los bots corriendo
docker ps --format "{{.Names}}" | grep bot | sort

# Ver estado de salud de todos los bots
docker ps --format "table {{.Names}}\t{{.Status}}" | grep bot

# Ver uso de red
docker network ls

# Ver interfaces de red virtuales
ip link show | grep veth | wc -l
```

## Solución si el Error de Red Persiste

Si al levantar un bot específico sigue dando error de red:

```bash
# Limpiar solo las redes (sin afectar contenedores)
docker network prune -f

# Esperar un momento
sleep 5

# Intentar levantar ese bot específico
docker compose up -d --build bot11

# Si falla, ver el error específico
docker compose logs bot11
```

## Resumen de Comandos Seguros

```bash
# ✅ SEGURO - No afecta contenedores corriendo
docker network prune -f

# ✅ SEGURO - Solo levanta bots específicos
docker compose up -d bot11 bot12 bot13

# ✅ SEGURO - Reinicia Docker (contenedores se reinician automáticamente)
sudo systemctl restart docker

# ❌ NO USAR - Detiene TODOS los contenedores
docker compose down

# ❌ NO USAR - Elimina contenedores
docker system prune -a
```

## Verificación Final

Después de levantar todos los bots:

```bash
# Debe mostrar 50 bots
docker ps | grep bot | wc -l

# Ver todos los bots con su estado
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep bot | sort

# Ver uso de recursos total
docker stats --no-stream
```

---

**Nota importante**: Con `restart: unless-stopped` en el docker-compose.yml, tus bots 1-10 están protegidos y se reiniciarán automáticamente si Docker se reinicia.
