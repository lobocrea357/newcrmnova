# Script para actualizar docker-compose.yml con bots 11-50

$dockerComposePath = "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\docker-compose.yml"
$tempFile = "c:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot\docker-compose-temp.yml"

Write-Host "Leyendo docker-compose.yml actual..." -ForegroundColor Cyan

# Leer el contenido actual
$content = Get-Content $dockerComposePath -Raw

# Encontrar la posición del dashboard (usando regex para manejar diferentes tipos de saltos de línea)
$dashboardPattern = "  # ============================================\s+# DASHBOARD"
if ($content -match $dashboardPattern) {
    $dashboardIndex = $content.IndexOf("  # ============================================", $content.IndexOf("# DASHBOARD") - 50)
} else {
    Write-Host "ERROR: No se encontro la seccion DASHBOARD" -ForegroundColor Red
    exit 1
}

# Parte antes del dashboard
$beforeDashboard = $content.Substring(0, $dashboardIndex)

# Parte desde el dashboard hasta el final
$fromDashboard = $content.Substring($dashboardIndex)

Write-Host "Generando configuraciones de bots 11-50..." -ForegroundColor Cyan

# Generar configuración de bots 11-50
$botsConfig = ""
for ($i = 11; $i -le 50; $i++) {
    $httpPort = 3100 + $i
    $apiPort = 3108 + $i
    
    $botsConfig += @"
  # ============================================
  # BOT $i - Asesor $i
  # ============================================
  bot${i}:
    build:
      context: ./bot$i
      dockerfile: Dockerfile
    container_name: bot${i}_asesor$i
    restart: unless-stopped
    env_file:
      - ./bot$i/.env
    environment:
      - PORT=$httpPort
      - API_PORT=$apiPort
      - BOT_NAME=Asesor $i
      - BOT_IDENTIFIER=bot$i
    ports:
      - "$httpPort`:$httpPort"
      - "$apiPort`:$apiPort"
    volumes:
      - bot${i}_data:/app/bot_sessions
    networks:
      - whatsapp_network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:$apiPort/status"]
      interval: 30s
      timeout: 10s
      retries: 3

"@
}

# Encontrar la sección de volumes
$volumesIndex = $fromDashboard.IndexOf("volumes:")
if ($volumesIndex -eq -1) {
    Write-Host "ERROR: No se encontro la seccion volumes" -ForegroundColor Red
    exit 1
}

$beforeVolumes = $fromDashboard.Substring(0, $volumesIndex + 8)
$afterVolumesHeader = $fromDashboard.Substring($volumesIndex + 8)

# Generar volúmenes para bots 11-50
$volumesConfig = ""
for ($i = 11; $i -le 50; $i++) {
    $volumesConfig += "`n  bot${i}_data:"
}

# Construir el nuevo contenido
$newContent = $beforeDashboard + $botsConfig + $beforeVolumes + $afterVolumesHeader.TrimStart() + $volumesConfig + "`n"

Write-Host "Escribiendo nuevo docker-compose.yml..." -ForegroundColor Cyan

# Guardar el nuevo contenido
Set-Content -Path $dockerComposePath -Value $newContent -Encoding UTF8

Write-Host "[COMPLETADO] docker-compose.yml actualizado con bots 11-50" -ForegroundColor Green
Write-Host "Total de bots configurados: 50" -ForegroundColor Green
