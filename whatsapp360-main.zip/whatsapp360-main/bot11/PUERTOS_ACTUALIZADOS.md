# 🔧 Actualización de Puertos - Bot 11

## ⚠️ Problema Detectado

El bot11 tenía un **conflicto de puertos** con bot19:

- **Bot11 (anterior)**: PORT=3111, API_PORT=**3119** ❌
- **Bot19**: PORT=**3119**, API_PORT=3127 ❌

El puerto 3119 estaba siendo usado por ambos bots, causando conflictos.

## ✅ Solución Aplicada

Se cambiaron los puertos de bot11 a valores más altos para evitar conflictos:

### Nuevos Puertos de Bot11:

| Tipo | Puerto Anterior | Puerto Nuevo |
|------|----------------|--------------|
| **PORT** (Bot) | 3111 | **3211** |
| **API_PORT** (API/QR) | 3119 | **3219** |

## 📝 Archivos Actualizados

Se actualizaron los siguientes archivos:

1. ✅ `docker-compose.yml` - Configuración de puertos del contenedor
2. ✅ `bot11/.env` - Variables de entorno
3. ✅ `bot11/Dockerfile` - Puertos expuestos
4. ✅ `fix-bot11.sh` - Script de solución (Bash)
5. ✅ `fix-bot11.ps1` - Script de solución (PowerShell)
6. ✅ `fix-bot11-vinculacion.sh` - Script de vinculación completo
7. ✅ `bot11/ERROR_AUTH_SOLUCION.md` - Documentación

## 🚀 Cómo Aplicar los Cambios

### Paso 1: Detener el bot actual
```bash
docker compose stop bot11
docker compose rm -f bot11
```

### Paso 2: Reconstruir con los nuevos puertos
```bash
docker compose build bot11
docker compose up -d bot11
```

### Paso 3: Verificar que funciona
```bash
# Ver logs
docker logs -f bot11_asesor11

# Verificar estado
curl http://localhost:3219/status
```

## 📱 Nueva URL para Escanear QR

### Antes:
- ❌ `http://localhost:3119`
- ❌ `http://[TU_IP]:3119`

### Ahora:
- ✅ `http://localhost:3219`
- ✅ `http://[TU_IP]:3219`

## 🔥 Firewall (Google Cloud VM)

Si estás en Google Cloud, necesitas abrir el nuevo puerto:

```bash
# Eliminar regla antigua (si existe)
gcloud compute firewall-rules delete allow-bot11 --quiet

# Crear nueva regla con el puerto correcto
gcloud compute firewall-rules create allow-bot11 \
    --allow tcp:3219 \
    --source-ranges 0.0.0.0/0 \
    --description "Bot 11 - API y QR"
```

## 🔍 Verificación de Puertos

Para verificar que no hay conflictos:

```bash
# Ver todos los puertos en uso
docker compose ps

# Verificar que bot11 usa los puertos correctos
docker port bot11_asesor11
```

Deberías ver:
```
3211/tcp -> 0.0.0.0:3211
3219/tcp -> 0.0.0.0:3219
```

## 📊 Mapa de Puertos de Todos los Bots

Para referencia, aquí están los puertos de todos los bots:

| Bot | PORT | API_PORT |
|-----|------|----------|
| bot1 | 3001 | 3009 |
| bot2 | 3002 | 3010 |
| bot3 | 3003 | 3011 |
| bot4 | 3004 | 3012 |
| bot5 | 3005 | 3013 |
| bot6 | 3106 | 3114 |
| bot7 | 3107 | 3115 |
| bot8 | 3108 | 3116 |
| bot9 | 3109 | 3117 |
| bot10 | 3110 | 3118 |
| **bot11** | **3211** | **3219** |
| bot12 | 3112 | 3120 |
| bot19 | 3119 | 3127 |

## ⚠️ Importante

- Los cambios ya están aplicados en los archivos de configuración
- Necesitas **reconstruir el contenedor** para que los cambios surtan efecto
- Actualiza cualquier referencia externa (Caddy, firewall, etc.) al nuevo puerto **3219**

## 🎯 Siguiente Paso

Ejecuta el script de solución completo:

```bash
cd ~/whatsapp360
chmod +x fix-bot11-vinculacion.sh
./fix-bot11-vinculacion.sh
```

Este script:
1. ✅ Limpia sesiones antiguas
2. ✅ Reconstruye el contenedor con los nuevos puertos
3. ✅ Espera 3 minutos para evitar bloqueo de WhatsApp
4. ✅ Te muestra la URL correcta para escanear el QR
