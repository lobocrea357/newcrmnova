# 🔧 Solución al Error "ERROR AUTH undefined" - Bot 11

## 📋 Descripción del Problema

El bot11 muestra el siguiente error:

```
[0] ⚡⚡ ACTION REQUIRED ⚡⚡
[0] You must scan the QR Code
[0] Remember that the QR code updates every minute
[1] ✅ QR copiado a: /app/bot_sessions/bot11.qr.png
[1] ✅ QR copiado a: /app/bot_sessions/bot11.qr.png
[1] ✅ QR copiado a: /app/bot_sessions/bot11.qr.png
[0] ⚡⚡ ERROR AUTH ⚡⚡
[0] undefined
```

Este error indica que el bot está generando el código QR correctamente, pero falla durante el proceso de autenticación con WhatsApp.

## 🔍 Causas Comunes

1. **Sesiones corruptas**: Archivos de sesión antiguos o dañados en el volumen Docker
2. **QR no escaneado a tiempo**: El QR expira cada minuto y no fue escaneado
3. **Problemas de red**: El contenedor no puede conectarse a los servidores de WhatsApp
4. **Versión incompatible**: Problemas con la versión de Baileys/WhatsApp Web

## ✅ Soluciones

### Solución 1: Script Automático (Recomendado)

#### En Windows (PowerShell):
```powershell
cd "C:\Users\loboc\OneDrive\Documents\proyectos\VIAJES NOVA\bot"
.\fix-bot11.ps1
```

#### En Linux/VM:
```bash
cd /ruta/a/tu/proyecto/bot
chmod +x fix-bot11.sh
./fix-bot11.sh
```

Este script automáticamente:
- ✅ Detiene el contenedor bot11
- ✅ Elimina sesiones corruptas
- ✅ Limpia el QR antiguo
- ✅ Reinicia el bot con configuración limpia
- ✅ Muestra los logs para verificar

### Solución 2: Manual Paso a Paso

#### Paso 1: Detener y limpiar el contenedor
```bash
docker-compose stop bot11
docker-compose rm -f bot11
docker volume rm bot_bot11_data -f
```

#### Paso 2: Limpiar archivos locales
```bash
# Limpiar sesiones
rm -rf ./bot11/bot_sessions/*

# Limpiar QR antiguo
rm -f ./bot11/bot.qr.png

# Limpiar base de datos (opcional)
echo "[]" > ./bot11/db.json
```

#### Paso 3: Reconstruir y reiniciar
```bash
docker-compose build bot11
docker-compose up -d bot11
```

#### Paso 4: Verificar logs
```bash
docker logs -f bot11_asesor11
```

### Solución 3: Verificar Configuración de Red

Si el problema persiste, verifica la configuración de red:

#### En Google Cloud VM:
```bash
# Verificar firewall
gcloud compute firewall-rules list | grep bot

# Crear regla si no existe
gcloud compute firewall-rules create allow-bot11 \
    --allow tcp:3119 \
    --source-ranges 0.0.0.0/0

# Obtener IP externa
curl -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip
```

#### Verificar conectividad del contenedor:
```bash
# Entrar al contenedor
docker exec -it bot11_asesor11 bash

# Verificar conectividad
ping -c 3 google.com
curl -I https://web.whatsapp.com

# Salir del contenedor
exit
```

## 📱 Cómo Escanear el QR Correctamente

1. **Acceder a la interfaz web**:
   - Local: `http://localhost:3219`
   - VM: `http://[TU_IP_EXTERNA]:3219`

2. **Abrir WhatsApp en tu teléfono**:
   - Ve a **Configuración** (⚙️)
   - Selecciona **Dispositivos vinculados**
   - Toca **Vincular un dispositivo**

3. **Escanear el QR**:
   - Apunta la cámara al código QR en la pantalla
   - Espera la confirmación
   - **IMPORTANTE**: Debes escanear dentro del primer minuto

4. **Verificar autenticación**:
   ```bash
   # Ver logs
   docker logs bot11_asesor11 --tail 20
   
   # Verificar estado
   curl http://localhost:3219/status
   ```

## 🔍 Diagnóstico Avanzado

### Ver logs en tiempo real:
```bash
docker logs -f bot11_asesor11
```

### Verificar estado del contenedor:
```bash
docker ps | grep bot11
docker inspect bot11_asesor11
```

### Verificar volúmenes:
```bash
docker volume ls | grep bot11
docker volume inspect bot_bot11_data
```

### Verificar archivos de sesión:
```bash
docker exec bot11_asesor11 ls -la /app/bot_sessions/
```

## 🚨 Problemas Conocidos

### Error persiste después de limpiar sesiones
**Solución**: Espera 5-10 minutos antes de intentar nuevamente. WhatsApp puede bloquear temporalmente intentos repetidos de autenticación.

### QR no se genera
**Solución**: 
```bash
# Verificar que el puerto esté disponible
netstat -an | grep 3119

# Reiniciar completamente
docker-compose down
docker-compose up -d bot11
```

### "Connection refused" al acceder al QR
**Solución**:
```bash
# Verificar que el contenedor esté corriendo
docker ps | grep bot11

# Verificar logs de errores
docker logs bot11_asesor11 | grep -i error
```

## 📞 Soporte Adicional

Si ninguna de estas soluciones funciona:

1. **Revisa la documentación oficial**: [BuilderBot Docs](https://builderbot.vercel.app/)
2. **Discord de la comunidad**: [Código en Casa Discord](https://link.codigoencasa.com/DISCORD)
3. **Verifica la versión de Baileys**: Puede haber incompatibilidades con versiones recientes de WhatsApp Web

## 📝 Notas Importantes

- ⚠️ El código QR expira cada **60 segundos**
- ⚠️ No intentes escanear el mismo QR múltiples veces
- ⚠️ Asegúrate de tener una conexión estable a internet
- ⚠️ WhatsApp puede limitar los intentos de vinculación si fallas muchas veces
- ✅ Después de una autenticación exitosa, la sesión se guarda y no necesitarás escanear nuevamente

## 🎯 Verificación Final

Después de aplicar la solución, deberías ver en los logs:

```
✅ Bot autenticado correctamente
🔄 Iniciando sincronización con Supabase...
✅ Servidor de API escuchando en http://localhost:3119
```

Y al acceder a `http://localhost:3219/status` deberías ver:

```json
{
  "qrAvailable": false,
  "authenticated": true,
  "message": "Bot autenticado correctamente"
}
```
