# Diagnóstico: No se puede conectar al servidor

## Error Actual
```
curl: (28) Failed to connect to dashboard.novapolointranet.xyz port 443 after 21037 ms: Could not connect to server
```

## Causa
El dominio `dashboard.novapolointranet.xyz` no está accesible desde tu máquina local.

## Posibles Razones

### 1. DNS no configurado
El dominio no tiene registros DNS apuntando al servidor.

### 2. Servidor no accesible desde internet
El servidor está en una red privada o detrás de un firewall.

### 3. Caddy no está corriendo
El servidor web Caddy no está levantado en el servidor.

### 4. Puertos cerrados
Los puertos 80 y 443 no están abiertos en el firewall del servidor.

## Verificaciones Necesarias

### Paso 1: Verificar DNS

```powershell
# Desde tu máquina local (Windows)
nslookup dashboard.novapolointranet.xyz

# O con dig (si tienes Git Bash)
dig dashboard.novapolointranet.xyz
```

**Resultado esperado**: Debe mostrar una IP pública del servidor.

**Si no resuelve**: El DNS no está configurado.

### Paso 2: Verificar IP del servidor

```bash
# Desde el servidor (SSH)
curl ifconfig.me
# O
curl icanhazip.com
```

Anota la IP pública del servidor.

### Paso 3: Verificar que Caddy está corriendo

```bash
# En el servidor
sudo systemctl status caddy

# Ver si está escuchando en los puertos
sudo netstat -tlnp | grep caddy
# O
sudo ss -tlnp | grep caddy
```

**Debe mostrar**:
```
*:80    LISTEN    caddy
*:443   LISTEN    caddy
```

### Paso 4: Verificar firewall del servidor

```bash
# En el servidor
sudo ufw status

# Debe mostrar:
# 80/tcp    ALLOW    Anywhere
# 443/tcp   ALLOW    Anywhere
```

### Paso 5: Probar conexión directa por IP

```powershell
# Desde tu máquina local
# Reemplaza XXX.XXX.XXX.XXX con la IP del servidor
curl -I http://XXX.XXX.XXX.XXX:3100

# Si funciona, el problema es DNS
# Si no funciona, el problema es el servidor/firewall
```

## Soluciones Según el Problema

### Solución 1: Configurar DNS (si no resuelve)

Necesitas crear registros DNS en tu proveedor de dominios:

```
Tipo: A
Nombre: dashboard.novapolointranet.xyz
Valor: IP_PUBLICA_DEL_SERVIDOR
TTL: 3600

Tipo: A
Nombre: *.novapolointranet.xyz (wildcard para todos los bots)
Valor: IP_PUBLICA_DEL_SERVIDOR
TTL: 3600
```

**Propagación DNS**: Puede tardar 5-60 minutos.

### Solución 2: Iniciar Caddy (si no está corriendo)

```bash
# En el servidor
cd ~/whatsapp360

# Copiar el Caddyfile al servidor
# (desde tu máquina local)
scp Caddyfile usuario@servidor:~/whatsapp360/

# En el servidor, instalar Caddy si no está instalado
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list
sudo apt update
sudo apt install caddy

# Copiar Caddyfile a la ubicación correcta
sudo cp ~/whatsapp360/Caddyfile /etc/caddy/Caddyfile

# Validar configuración
sudo caddy validate --config /etc/caddy/Caddyfile

# Iniciar Caddy
sudo systemctl enable caddy
sudo systemctl start caddy
sudo systemctl status caddy
```

### Solución 3: Abrir puertos en el firewall

```bash
# En el servidor
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw reload
sudo ufw status
```

### Solución 4: Verificar que los bots están corriendo

```bash
# En el servidor
cd ~/whatsapp360
docker ps | grep dashboard

# Si no está corriendo
docker compose up -d dashboard

# Ver logs
docker compose logs -f dashboard
```

### Solución 5: Usar archivo hosts temporalmente (para pruebas)

Si el DNS no está configurado aún, puedes probar localmente:

```powershell
# En tu máquina Windows (como Administrador)
notepad C:\Windows\System32\drivers\etc\hosts

# Agregar esta línea (reemplaza con la IP real del servidor)
XXX.XXX.XXX.XXX dashboard.novapolointranet.xyz
XXX.XXX.XXX.XXX bot-uno.novapolointranet.xyz
XXX.XXX.XXX.XXX bot-dos.novapolointranet.xyz
# ... etc
```

Guardar y probar:
```powershell
curl -I http://dashboard.novapolointranet.xyz:3100
```

## Comandos de Diagnóstico Completo

### Desde tu máquina local (Windows):

```powershell
# 1. Verificar DNS
nslookup dashboard.novapolointranet.xyz

# 2. Hacer ping
ping dashboard.novapolointranet.xyz

# 3. Probar conexión HTTP
curl -I http://dashboard.novapolointranet.xyz

# 4. Probar conexión HTTPS
curl -I https://dashboard.novapolointranet.xyz

# 5. Ver traceroute
tracert dashboard.novapolointranet.xyz
```

### Desde el servidor (SSH):

```bash
# 1. Ver IP pública
curl ifconfig.me

# 2. Ver servicios corriendo
sudo systemctl status caddy
sudo systemctl status docker

# 3. Ver puertos abiertos
sudo netstat -tlnp | grep -E '(80|443|3100)'

# 4. Ver contenedores
docker ps | grep dashboard

# 5. Ver logs de Caddy
sudo journalctl -u caddy -n 50 -f

# 6. Ver logs del dashboard
docker compose logs -f dashboard

# 7. Probar localmente en el servidor
curl -I http://localhost:3100
curl -I http://localhost:80
```

## Checklist de Configuración

- [ ] DNS configurado (A record apuntando a IP del servidor)
- [ ] Servidor accesible desde internet
- [ ] Puertos 80 y 443 abiertos en firewall
- [ ] Caddy instalado y corriendo
- [ ] Caddyfile copiado al servidor
- [ ] Dashboard corriendo en Docker (puerto 3100)
- [ ] Bots corriendo en Docker (puertos 3009-3158)

## Escenarios Comunes

### Escenario 1: Servidor en red local (no accesible desde internet)

Si tu servidor está en `192.168.x.x` o `10.x.x.x`:

**Solución**: 
- Configurar port forwarding en tu router (80 → servidor:80, 443 → servidor:443)
- O usar un túnel como ngrok/cloudflare tunnel
- O acceder solo desde la red local usando la IP interna

### Escenario 2: Servidor en la nube (AWS, DigitalOcean, etc.)

**Solución**:
- Verificar Security Groups (AWS) o Firewall rules (DigitalOcean)
- Asegurar que los puertos 80 y 443 están abiertos
- Configurar DNS apuntando a la IP elástica/flotante

### Escenario 3: Dominio recién configurado

**Solución**:
- Esperar 5-60 minutos para propagación DNS
- Verificar con: `nslookup dashboard.novapolointranet.xyz 8.8.8.8`
- Usar `curl -I http://IP_SERVIDOR:3100` mientras tanto

## Próximos Pasos

1. **Ejecuta el diagnóstico** desde tu máquina local
2. **Conéctate al servidor** por SSH
3. **Ejecuta el diagnóstico** desde el servidor
4. **Comparte los resultados** para identificar el problema exacto

---

**Nota**: Estás intentando conectarte desde tu máquina local (Windows) al servidor. El Caddyfile que configuramos debe estar en el servidor, no en tu máquina local.
