# Configuración de Bots 11-50

## Resumen
Se han configurado exitosamente 40 bots adicionales (del bot11 al bot50) siguiendo la misma estructura y organización de los bots 1-10.

## Estructura de Puertos

Cada bot tiene asignados 2 puertos:
- **Puerto HTTP**: 3100 + número de bot
- **Puerto API**: 3108 + número de bot

### Tabla de Puertos

| Bot | Puerto HTTP | Puerto API | Nombre | Identificador |
|-----|-------------|------------|--------|---------------|
| bot11 | 3111 | 3119 | Asesor 11 | bot11 |
| bot12 | 3112 | 3120 | Asesor 12 | bot12 |
| bot13 | 3113 | 3121 | Asesor 13 | bot13 |
| bot14 | 3114 | 3122 | Asesor 14 | bot14 |
| bot15 | 3115 | 3123 | Asesor 15 | bot15 |
| bot16 | 3116 | 3124 | Asesor 16 | bot16 |
| bot17 | 3117 | 3125 | Asesor 17 | bot17 |
| bot18 | 3118 | 3126 | Asesor 18 | bot18 |
| bot19 | 3119 | 3127 | Asesor 19 | bot19 |
| bot20 | 3120 | 3128 | Asesor 20 | bot20 |
| bot21 | 3121 | 3129 | Asesor 21 | bot21 |
| bot22 | 3122 | 3130 | Asesor 22 | bot22 |
| bot23 | 3123 | 3131 | Asesor 23 | bot23 |
| bot24 | 3124 | 3132 | Asesor 24 | bot24 |
| bot25 | 3125 | 3133 | Asesor 25 | bot25 |
| bot26 | 3126 | 3134 | Asesor 26 | bot26 |
| bot27 | 3127 | 3135 | Asesor 27 | bot27 |
| bot28 | 3128 | 3136 | Asesor 28 | bot28 |
| bot29 | 3129 | 3137 | Asesor 29 | bot29 |
| bot30 | 3130 | 3138 | Asesor 30 | bot30 |
| bot31 | 3131 | 3139 | Asesor 31 | bot31 |
| bot32 | 3132 | 3140 | Asesor 32 | bot32 |
| bot33 | 3133 | 3141 | Asesor 33 | bot33 |
| bot34 | 3134 | 3142 | Asesor 34 | bot34 |
| bot35 | 3135 | 3143 | Asesor 35 | bot35 |
| bot36 | 3136 | 3144 | Asesor 36 | bot36 |
| bot37 | 3137 | 3145 | Asesor 37 | bot37 |
| bot38 | 3138 | 3146 | Asesor 38 | bot38 |
| bot39 | 3139 | 3147 | Asesor 39 | bot39 |
| bot40 | 3140 | 3148 | Asesor 40 | bot40 |
| bot41 | 3141 | 3149 | Asesor 41 | bot41 |
| bot42 | 3142 | 3150 | Asesor 42 | bot42 |
| bot43 | 3143 | 3151 | Asesor 43 | bot43 |
| bot44 | 3144 | 3152 | Asesor 44 | bot44 |
| bot45 | 3145 | 3153 | Asesor 45 | bot45 |
| bot46 | 3146 | 3154 | Asesor 46 | bot46 |
| bot47 | 3147 | 3155 | Asesor 47 | bot47 |
| bot48 | 3148 | 3156 | Asesor 48 | bot48 |
| bot49 | 3149 | 3157 | Asesor 49 | bot49 |
| bot50 | 3150 | 3158 | Asesor 50 | bot50 |

## Archivos Configurados

Para cada bot (bot11 a bot50) se han configurado:

### 1. Dockerfile
- Construcción multi-etapa con Node.js 21
- Imagen base: `node:21-bookworm`
- Imagen producción: `node:21-bookworm-slim`
- Dependencias de sistema: `libvips`, `curl`
- Puertos expuestos específicos para cada bot
- Variables de entorno configuradas

### 2. Archivo .env
Cada bot tiene su archivo `.env` con:
```env
OPENAI_API_KEY=<key>
PORT=<puerto_http>
API_PORT=<puerto_api>
SUPABASE_URL=https://yibmuomckbaxdvawhdul.supabase.co
SUPABASE_ANON_KEY=<key>
SUPABASE_SERVICE_ROLE_KEY=<key>
BOT_NAME=Asesor <número>
BOT_IDENTIFIER=bot<número>
```

### 3. docker-compose.yml
Se agregaron:
- 40 servicios de bots (bot11 a bot50)
- Configuración de red `whatsapp_network`
- Healthchecks para cada bot
- 40 volúmenes persistentes (bot11_data a bot50_data)

## Características de Cada Bot

- **Restart Policy**: `unless-stopped`
- **Network**: `whatsapp_network` (bridge)
- **Volumen**: Persistencia de sesiones en `/app/bot_sessions`
- **Healthcheck**: Verificación cada 30s en el endpoint `/status` del puerto API
- **Build Context**: Directorio propio de cada bot

## Scripts Creados

### configurar-bots-11-50.ps1
Script que actualiza automáticamente:
- Dockerfiles de bot11 a bot50
- Archivos .env de bot11 a bot50

### actualizar-docker-compose.ps1
Script que actualiza el `docker-compose.yml` agregando:
- Servicios de bot11 a bot50
- Volúmenes correspondientes

## Comandos Útiles

### Iniciar todos los bots
```bash
docker-compose up -d
```

### Iniciar solo bots específicos (ejemplo: bot11 a bot15)
```bash
docker-compose up -d bot11 bot12 bot13 bot14 bot15
```

### Ver logs de un bot específico
```bash
docker-compose logs -f bot25
```

### Detener todos los bots
```bash
docker-compose down
```

### Reconstruir un bot específico
```bash
docker-compose build bot30
docker-compose up -d bot30
```

### Ver estado de todos los servicios
```bash
docker-compose ps
```

## Verificación

Para verificar que un bot está funcionando correctamente:

1. **Verificar el contenedor**:
   ```bash
   docker ps | grep bot25
   ```

2. **Verificar el healthcheck**:
   ```bash
   docker inspect bot25_asesor25 | grep -A 10 Health
   ```

3. **Verificar los logs**:
   ```bash
   docker-compose logs bot25
   ```

4. **Probar el endpoint de status**:
   ```bash
   curl http://localhost:3133/status
   ```

## Notas Importantes

1. **Puertos**: Asegúrate de que los puertos 3111-3158 estén disponibles en el servidor
2. **Recursos**: 50 bots simultáneos requieren recursos significativos (RAM, CPU)
3. **Sesiones**: Cada bot mantiene su sesión de WhatsApp independiente
4. **Escalabilidad**: Puedes iniciar solo los bots que necesites

## Próximos Pasos

1. Iniciar los bots gradualmente para monitorear recursos
2. Configurar cada bot con su número de WhatsApp correspondiente
3. Verificar que cada bot se conecta correctamente a Supabase
4. Monitorear el uso de recursos del servidor

## Estructura de Directorios

```
bot/
├── bot1/
├── bot2/
├── ...
├── bot10/
├── bot11/          # Nuevos bots configurados
├── bot12/
├── ...
├── bot50/
├── dashboard/
├── docker-compose.yml
└── scripts/
```

## Total de Bots Configurados

- **Bots 1-10**: 10 bots (ya existentes)
- **Bots 11-50**: 40 bots (recién configurados)
- **Total**: 50 bots de WhatsApp independientes
